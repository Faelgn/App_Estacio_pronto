Aqui está o começo do nosso projeto em kotlin da estácio, para apresentar ao professor Lucas Leite, na terça feira dia 14/04/2024.
ass: Rafael Lucas Gouveia do Nascimento
