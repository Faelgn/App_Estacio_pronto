package projeto.android.appestacio

class ListData (
    var name: String,
    var peso: String,
    var carac: Int,
    var desc: Int,
    var image: Int
)